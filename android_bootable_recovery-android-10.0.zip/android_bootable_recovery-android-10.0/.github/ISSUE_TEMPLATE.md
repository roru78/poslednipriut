- [ ] I am running an official build of TWRP, downloaded from https://twrp.me/Devices/
- [ ] I am running the latest version of TWRP
- [ ] I have read the FAQ (https://twrp.me/FAQ/)
- [ ] I have searched for my issue and it does not already exist

**Device codename**: <!-- Device codename -->
**TWRP version**: <!-- TWRP version installed -->

#### WHAT STEPS WILL REPRODUCE THE PROBLEM?
<!-- Explain the steps necessary to reproduce the problem, as completely as possible -->

#### WHAT IS THE EXPECTED RESULT?
<!-- Explain what the expected result is, as completely as possible -->

#### WHAT HAPPENS INSTEAD?
<!-- Explain what happens instead, as completely as possible -->

#### ADDITIONAL INFORMATION
<!-- Add any additional information you know about the issue, such as possible causes and solutions -->

<!-- Use https://paste.omnirom.org/ and upload `/tmp/recovery.log` and the output of `dmesg` -->
`/tmp/recovery.log`: <!-- Link here -->
`dmesg`: <!-- Link here -->
